<?php

namespace TrueBV\Exception;

/**
 * Class LabelOutOfBoundsException
 * @package TrueBV\Exception
 * @author  Sebastian Kroczek <sk@xbug.de>
 */
class LabelOutOfBoundsException extends OutOfBoundsException
{

}
